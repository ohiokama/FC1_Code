
package Lec2_variable;
public class ex1 {
    public static void main(String[] args) {
        System.out.println("Exercise 1:");
        System.out.println("1 + 2 = " + (1 + 2));
        System.out.println("3.5 + 8 = " + (3.5 + 8));
        System.out.println("1 / 2 = " + (1 / 2)); 
        System.out.println("4.5 + 7 = " + (4.5 + 7));
        System.out.println("4 * 5 + 1 = " + (4 * 5 + 1));
        System.out.println("20 % 3 + 2 - 7 = " + (20 % 3 + 2 - 7));
    }
}
